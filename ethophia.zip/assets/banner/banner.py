from assets.colors.colors import colors
def banner():
    banner = f"""

{colors.red}╔═╗{colors.magenta}╔╦╗{colors.red}╦ ╦{colors.magenta}╔═╗{colors.red}╔═╗{colors.magenta}╦{colors.red}╔═╗  {colors.green}╔═╗╦═╗╔═╗ ╦╔═╗╔═╗╔╦╗
{colors.red}║╣ {colors.magenta} ║ {colors.red}╠═╣{colors.magenta}║ ║{colors.red}╠═╝{colors.magenta}║{colors.red}╠═╣  {colors.green}╠═╝╠╦╝║ ║ ║║╣ ║   ║ 
{colors.red}╚═╝{colors.magenta} ╩ {colors.red}╩ ╩{colors.magenta}╚═╝{colors.red}╩  {colors.magenta}╩{colors.red}╩ ╩  {colors.green}╩  ╩╚═╚═╝╚╝╚═╝╚═╝ ╩ {colors.reset}

GITHUB => https://github.com/1llsion/
TELEGRAM => https://t.me/1llsion
{colors.red}[!] This tool for education only{colors.reset}\n 
{colors.cyan}[{colors.reset} 1 {colors.cyan}] {colors.reset}HEADER INFORMATION
{colors.cyan}[{colors.reset} 2 {colors.cyan}] {colors.reset}WORDPRESS BRUTEFORCE
{colors.cyan}[{colors.reset} 3 {colors.cyan}] {colors.reset}PASSWORD DECRYPT MD2,MD4,MD5,MYSQL,SHA1,SHA256,SHA224,SHA384,SHA512,SHA3_256,BLAKE2B,BCRYPT
{colors.cyan}[{colors.reset} 4 {colors.cyan}] {colors.reset}CMS SCANNER
{colors.cyan}[{colors.reset} 5 {colors.cyan}] {colors.reset}SHELL FINDER
{colors.cyan}[{colors.reset} 6 {colors.cyan}] {colors.reset}ADMIN FINDER


    """
    print(banner)
