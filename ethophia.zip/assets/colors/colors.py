from colorama import Fore, Style, init
init(autoreset=True)

class colors:
    green = Fore.LIGHTGREEN_EX
    cyan = Fore.LIGHTCYAN_EX
    magenta = Fore.LIGHTMAGENTA_EX
    yellow = Fore.LIGHTYELLOW_EX
    red = Fore.RED
    reset = Style.RESET_ALL