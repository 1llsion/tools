import requests
import socket
from urllib.parse import urlparse
from lib.colors.colors import *
from bs4 import BeautifulSoup
import builtwith

init()

# Colors
space = "   "
x = "="*45
# Banners
def banner():
    banner = f"""
    
{space}{space}{colors.blue}╦ ╦╔╦╗  ╦╔╗╔╔═╗╔═╗
{space}{space}{colors.blue}╠═╣ ║║  ║║║║╠╣ ║ ║
{space}{space}{colors.cyan}╩ ╩═╩╝  ╩╝╚╝╚  ╚═╝{colors.reset}\n 
[*] Header Security Information
[*] Created By Low Security
[*] You don't get information from this tool? that means you are stupid!!
[*] Don't be stupid bro!!
    """
    print(banner)
    
# Function Get Information Header
class HeaderScanner:
    def __init__(self):
        self.client_headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US;q=0.8,en;q=0.3',
            'Upgrade-Insecure-Requests': "1"
        }

        self.sec_headers = {
            'X-XSS-Protection': 'deprecated',
            'X-Frame-Options': 'warning',
            'X-Content-Type-Options': 'warning',
            'Strict-Transport-Security': 'error',
            'Content-Security-Policy': 'warning',
            'X-Permitted-Cross-Domain-Policies': 'deprecated',
            'Referrer-Policy': 'warning',
            'Expect-CT': 'deprecated',
            'Permissions-Policy': 'warning',
            'Cross-Origin-Embedder-Policy': 'warning',
            'Cross-Origin-Resource-Policy': 'warning',
            'Cross-Origin-Opener-Policy': 'warning'
        }

        self.information_headers = {
            'X-Powecolors.red-By',
            'Server',
            'X-AspNet-Version',
            'X-AspNetMvc-Version'
        }

        self.cache_headers = {
            'Cache-Control',
            'Pragma',
            'Last-Modified',
            'Expires',
            'ETag'
        }

        self.headers = {}
    def get_header_info(self, url):
        try:
            response = requests.head(url, headers=self.client_headers)
            self.headers = response.headers

            print(f"\n[{colors.cyan} * {colors.reset}] Analyzing URL: {colors.green}{url}{colors.reset}")
            self.scan_headers()
            ip = self.detect_ip(url)
            if ip:
                self.ip_location(ip)
            self.detect_framework(url)

        except requests.exceptions.RequestException as e:
            print("Error:", e)

    def scan_headers(self):
        self.check_header_category("Security Headers", self.sec_headers)
        self.check_header_category("Information Headers", self.information_headers)
        self.check_header_category("Cache Headers", self.cache_headers)

    def check_header_category(self, category_name, headers_to_check):
        print(x)
        print(f"\n[{colors.cyan} * {colors.reset}] {colors.blue}{category_name}{colors.reset} : ")
        for header_name in headers_to_check:
            self.check_header(header_name)

    def check_header(self, header_name):
        if header_name in self.headers:
            print(f"[{colors.cyan} * {colors.reset}] {colors.blue}{header_name}{colors.reset}: {colors.yellow}{self.headers[header_name]}{colors.reset}")
        else:
            print(f"[{colors.red} ! {colors.reset}] {colors.blue}{header_name}{colors.reset}:{colors.red} Not found{colors.reset}")
    def detect_ip(self, url):
        try:
            ip = socket.gethostbyname(urlparse(url).hostname)
            print(f"\n[{colors.cyan} * {colors.reset}] IP Address: {colors.yellow}{ip}{colors.reset}")
            return ip
        except socket.gaierror as e:
            print("\n[{colors.red} ! {colors.reset}] Failed to get IP address:", e)
            return None
    def ip_location(self, ip):
        try:
            api_url = f"http://ip-api.com/json/{ip}"
            response = requests.get(api_url)
            data = response.json()

            if data['status'] == 'success':
                country = data['country']
                region = data['regionName']
                city = data['city']
                isp = data['isp']
                lat = data['lat']
                lon = data['lon']
                print(f"\nIP information ")
                print(x)
                print(f"[{colors.green}?{colors.reset}] Country   ={colors.yellow} {country}")
                print(f"[{colors.green}?{colors.reset}] Region    ={colors.yellow} {region}")
                print(f"[{colors.green}?{colors.reset}] City      ={colors.yellow} {city}")
                print(f"[{colors.green}?{colors.reset}] ISP       ={colors.yellow} {isp}")
                print(f"[{colors.green}?{colors.reset}] Latitude  ={colors.yellow} {lat}")
                print(f"[{colors.green}?{colors.reset}] Longitude ={colors.yellow} {lon}{colors.reset}")
                
            else:
                print("\n[*] IP Location information not found.")
        except requests.exceptions.RequestException as e:
            print("\n[ ! ] Failed to get IP location:", e)
    def detect_framework(self, url):
        try:
            technologies = builtwith.builtwith(url)

            if technologies:
                print("\nDetected Technologies:")
                print(x)
                for tech, version in technologies.items():
                    print(f"[{colors.green}?{colors.reset}] {tech}: {colors.yellow}{version[0]}{colors.reset}")
            else:
                print("\n[*] No technologies detected.")

        except requests.exceptions.RequestException as e:
            print("\n[ ! ] Failed to detect framework:", e)
def hdinfo():
    banner()
    scanner = HeaderScanner()
    target = input("Input Your Url => ")
    scanner.get_header_info(target)