from lib.colors.colors import *
import subprocess

class WebScanner:
    LIMITATOR = 10
    DEFAULT_PATH = "/wp-admin/load-scripts.php?c=1&load=editor,common,user-profile,media-widgets,media-gallery/"

    def __init__(self):
        self.list_file = ""
        self.keyword = ""
        self.save_as = ""
        self.colors = Colors()

    def options(self):
        print(f"{colors.green}[{colors.red} > {colors.reset}] List                        :", end=" ")
        self.list_file = input().strip()
        print(f"{colors.green}[{colors.red} > {colors.reset}] Keyword                     :", end=" ")
        self.keyword = input().strip()
        print(f"{colors.green}[{colors.red} > {colors.reset}] Save As                     :", end=" ")
        self.save_as = input().strip()

    def check_vulnerability(self, site):
        # Coba dengan HTTPS
        try:
            response_https = subprocess.check_output(["curl", "--connect-timeout", "3", "--max-time", "3", "-kLs", f"{site}{self.DEFAULT_PATH}"]).decode('utf-8')
            if self.keyword in response_https:
                print(f"{colors.red}[{colors.green} + {colors.red}]{colors.reset} {site} : {colors.green}is vuln{colors.reset}")
                with open(self.save_as, "a") as file:
                    file.write(f"https://{site}{self.DEFAULT_PATH}\n")
            else:
                # Jika respons HTTPS tidak sesuai, coba dengan HTTP
                print(f"{colors.green}[{colors.red} * {colors.green}]{colors.reset} {site} : {colors.red}is Bad {colors.reset}")
                print(f"Trying HTTP for {site}...")
                response_http = subprocess.check_output(["curl", "--connect-timeout", "3", "--max-time", "3", "-s", f"http://{site}{self.DEFAULT_PATH}"]).decode('utf-8')
                if self.keyword in response_http:
                    print(f"{colors.red}[{colors.green} + {colors.red}]{colors.reset} {site} : {colors.green}is vuln {colors.reset}")
                    with open(self.save_as, "a") as file:
                        file.write(f"http://{site}{self.DEFAULT_PATH}\n")
                else:
                    print(f"{colors.green}[{colors.red} * {colors.green}]{colors.reset} {site} : {colors.red}is Bad {colors.reset}")
        except subprocess.CalledProcessError as e:
            print(f"{colors.green}[{colors.red} * {colors.green}]{colors.reset} {site} : {colors.red}URL is not valid or you stupid hehe JK :( {colors.reset}")

    def scan_websites(self):
        self.options()
        print(f"\n{colors.cyan}STARTING MASSEH....{colors.reset}\n")
        
        with open(self.list_file, "r") as file:
            sites = file.read().splitlines()

        for site in sites:
            self.check_vulnerability(site)

        print(f"\n{colors.cyan}ANJAY DAPET GAK TUH BEB WKWKW{colors.reset} {self.save_as}...\n")
        print(f"\n{colors.green}NAH KALAU DAPET LU BISA PAKAI MENU TAKEDOWN WP BECAUSE INI KHUSUS WP :({colors.reset}\n")

    
