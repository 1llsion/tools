import os
import urllib.parse
import json

class SitemapGenerator:
    def __init__(self):
        self.sitemap_template = """<?xml version="1.0" encoding="UTF-8"?>
<urlset
  xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
            http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
<!-- created with Free Online Sitemap Generator www.xml-sitemaps.com -->
{urls}
</urlset>"""

    def generate_single_page_sitemap(self, url):
        sitemap_content = f"<url>\n<loc>{url}</loc>\n</url>"
        self.save_sitemap(url, sitemap_content)

    def generate_tunnel_sitemap(self, url, params, brands):
        urls = ""
        for brand in brands:
            brand_str = urllib.parse.quote(brand.strip())
            urls += f"<url>\n<loc>{url}/{params}{brand_str}</loc>\n</url>\n"

        self.save_sitemap(url, urls)

    def save_sitemap(self, url, content):
        filename = f"{self.clean_filename(url)}.xml"
        with open(filename, "w", encoding="utf-8") as f:
            f.write(self.sitemap_template.format(urls=content))
        print(f"Sitemap saved as {filename}")

    def clean_filename(self, filename):
        return "".join(c if c.isalnum() or c in ['.', '_'] else '_' for c in filename)

    def generate_from_config(self, config_path):
        with open(config_path, "r", encoding="utf-8") as config_file:
            config = json.load(config_file)

        for sitemap in config["sitemaps"]:
            if sitemap["type"] == "single_page":
                self.generate_single_page_sitemap(sitemap["url"])
            elif sitemap["type"] == "tunnel":
                self.generate_tunnel_sitemap(sitemap["url"], sitemap["params"], sitemap["brands"])

def map():
    generator = SitemapGenerator()

    user_choice = input("Choose sitemap type (single_page/tunnel/config): ").lower()

    if user_choice == "single_page":
        single_page_url = input("Enter single page URL: ")
        generator.generate_single_page_sitemap(single_page_url)
    elif user_choice == "tunnel":
        tunnel_url = input("Enter tunnel URL: ")
        tunnel_params = input("Enter tunnel params: ")
        tunnel_brands = input("Enter path to brands file: ")

        with open(tunnel_brands, "r", encoding="utf-8") as brands_file:
            brands_list = [brand.strip() for brand in brands_file.readlines()]

        generator.generate_tunnel_sitemap(tunnel_url, tunnel_params, brands_list)
    elif user_choice == "config":
        config_path = input("Enter path to config file: ")
        generator.generate_from_config(config_path)
    else:
        print("Invalid choice.")
