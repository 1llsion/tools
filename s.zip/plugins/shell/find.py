import requests
import os
from lib.colors.colors import Colors
from concurrent.futures import ThreadPoolExecutor

x = "="*40
class ShellScanner:
    def __init__(self, target_file, dir_list_file, file_list_file, num_threads=10):
        self.target_urls = self.load_list_from_file(target_file)
        self.dir_list_file = dir_list_file
        self.file_list_file = file_list_file
        self.colors = Colors()
        self.num_threads = num_threads

    def load_list_from_file(self, file_path):
        try:
            with open(file_path, "r") as file:
                return [line.strip() for line in file.readlines()]
        except FileNotFoundError:
            print(f"[{self.colors.blue}Info{self.colors.reset}] File not found: {file_path}")
        except Exception as e:
            print(f"[{self.colors.red}Error{self.colors.reset}] An error occurred while loading file: {file_path}", e)

    def scan_directories(self, target_url, directories, current_path=""):
        try:
            with ThreadPoolExecutor(max_workers=self.num_threads) as executor:
                futures = [executor.submit(self.scan_directory, target_url, directory, current_path) for directory in directories]

            for future in futures:
                future.result()

        except requests.exceptions.RequestException as e:
            print(f"[{self.colors.red} ! {self.colors.reset}] An error occurred:", e)

    def scan_directory(self, target_url, directory, current_path):
        dir_path = os.path.join(current_path, directory)
        url = f"{target_url}/{dir_path}"

        try:
            response = requests.head(url, verify=True)
        except requests.exceptions.SSLError:
            url = url.replace("https://", "http://")
            response = requests.head(url, verify=False)

        if response.status_code == 403:
            print(f"[{self.colors.green}FOUND{self.colors.reset}] Directory: {url}")
            self.scan_files(target_url, directory, current_path)
        elif response.status_code == 200:
            print(f"[{self.colors.cyan}Directory Listening{self.colors.reset}] Directory: {url}")
            self.scan_files(target_url, directory, current_path)
        elif response.status_code == 301:
            print(f"[{self.colors.yellow}Redirect{self.colors.reset}] Directory: {url}")
        else:
            print(f"[{self.colors.red}NOT FOUND{self.colors.reset}] Directory: {url}")

    def scan_files(self, target_url, directory, current_path):
        file_list = self.load_list_from_file(self.file_list_file)
        if file_list:
            with ThreadPoolExecutor(max_workers=self.num_threads) as executor:
                futures = [executor.submit(self.scan_file, target_url, file, directory, current_path) for file in file_list]

            for future in futures:
                future.result()

    def scan_file(self, target_url, file, directory, current_path):
        file_path = os.path.join(current_path, directory, file)
        url = f"{target_url}/{file_path}"

        try:
            response = requests.head(url, verify=True)
        except requests.exceptions.SSLError:
            url = url.replace("https://", "http://")
            response = requests.head(url, verify=False)

        if response.status_code == 200:
            print(f"[{self.colors.yellow}FOUND{self.colors.reset}] File: {url}")
        else:
            print(f"[{self.colors.red}NOT FOUND{self.colors.reset}] File: {url}")

    def start_scan(self):
        for target_url in self.target_urls:
            print(f"\nScanning target:{self.colors.blue} {target_url}{self.colors.reset}")
            print(x)
            dir_list = self.load_list_from_file(self.dir_list_file)
            if dir_list:
                self.scan_directories(target_url, dir_list)

def mainscan():
    target_file = input("Input the target file (e.g., targets.txt): ")
    dir_list_file = "lib/config/dir.txt"
    file_list_file = "lib/config/file.txt"

    scanner = ShellScanner(target_file, dir_list_file, file_list_file, num_threads=10)
    scanner.start_scan()

