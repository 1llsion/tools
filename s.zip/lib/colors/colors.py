from colorama import Fore, Style, init

class Colors:
    def __init__(self):
        init()
        self.blue = Fore.LIGHTBLUE_EX
        self.red = Fore.RED
        self.cyan = Fore.LIGHTCYAN_EX
        self.yellow = Fore.LIGHTYELLOW_EX
        self.green = Fore.LIGHTGREEN_EX
        self.reset = Style.RESET_ALL
colors = Colors()